var backgroundImg,backgrd;
var player, playerImg;
var enemy1,enemy1Img,enemy2,enemy2Img,enemy3,enemy3Img,enemy4,enemy4Img;
var enemyGroup;
var score = 0;

function preload(){
  backgroundImg = loadImage("background.png");
  playerImg = loadImage("spaceship.png");
  enemy1Img = loadImage("enemy.png");
  enemy2Img = loadImage("enemy.png");
  enemy3Img = loadImage("enemy.png");
  enemy4Img = loadImage("enemy.png");
  
}

function setup() {
 createCanvas(600,500);
 backgrd = createSprite(300,200);
  backgrd.addImage("backgrd",backgroundImg);
  backgrd.scale=0.9999;
  
  player = createSprite(100,200);
  player.addImage("player",playerImg);
  player.scale = 0.15;
  
  enemyGroup = createGroup();
  
  score = 0;
}

function draw() {
 background(300);
  
   if (backgrd.x < 250){
       backgrd.x = backgrd.width/2;
    }
  //if(keyDown("S")){
   backgrd.velocityX = -4;
    
   //}
  text("score: "+ score,300,50);
  player.velocityY = player.velocityY + 0.8;
  
  if(keyDown("space")) {
        player.velocityY = -4;
        
    }
  score = score + Math.round(getFrameRate()/60);
  if(enemyGroup.isTouching(player)){
    player.velocityY = 0;
    
    
    backgrd.velocityX = 0;
    enemyGroup.setLifetimeEach(-1);
   
     
     enemyGroup.setVelocityXEach(0);
       
  }
  spawnEnemy();
 drawSprites();
}
function spawnEnemy(){
 if (frameCount % 60 === 0){
   enemy1 = createSprite(500,100);
   
  
   enemy2 = createSprite(500,200);
   
  
   enemy3 = createSprite(500,300);
   
 
   enemy4 = createSprite(500,400);
   
   
    //generate random obstacles
    var rand = Math.round(random(1,4));
    switch(rand) {
      case 1:enemy1.addImage("enemy1",enemy1Img); 
             enemy1.scale = 0.14;
              break;
      case 2: enemy2.addImage("enemy2",enemy2Img);
              enemy2.scale = 0.14;
              break;
      case 3: enemy3.addImage("enemy3",enemy3Img);
              enemy3.scale = 0.14;
              break;
      case 4: enemy4.addImage("enemy4",enemy4Img);
              enemy4.scale = 0.14;
              break;
      
      default: break;
    }
   
    //assign scale and lifetime to the obstacle           
    
      enemy1.velocityX = -6;
      enemy2.velocityX = -6;
      enemy3.velocityX = -6;
      enemy4.velocityX = -6;
    
    enemy1.lifetime = 300;
    enemy2.lifetime = 300;
    enemy3.lifetime = 300;
    enemy4.lifetime = 300;
   //add each obstacle to the group
   enemyGroup.add(enemy1 && enemy2 && enemy3 && enemy4);
     
  
 }
}
  